"""
Unit Tests for EV AI Engine & Fallback Reasoning
"""

import unittest
from core.ai_engine import ai_engine

class TestAIEngine(unittest.TestCase):
    def test_offline_persona_responses(self):
        success, resp = ai_engine.generate_response("who are you")
        self.assertTrue(success)
        self.assertIn("EV", resp)
        self.assertIn("Enhanced Virtual Intelligence", resp)

    def test_offline_status_query(self):
        success, resp = ai_engine.generate_response("are you there")
        self.assertTrue(success)
        self.assertIn("online", resp.lower())

    def test_offline_concept_explanation(self):
        success, resp = ai_engine.generate_response("what is artificial intelligence")
        self.assertTrue(success)
        self.assertIn("computer science", resp.lower())

    def test_offline_math_calculation(self):
        success, resp = ai_engine.generate_response("calculate 25 * 4 + 10")
        self.assertTrue(success)
        self.assertIn("110", resp)

if __name__ == "__main__":
    unittest.main()

