"""
Unit Tests for EV Command Router & Allowlisted Automation
"""

import unittest
from unittest.mock import patch, MagicMock
from core.command_router import command_router

class TestCommandRouter(unittest.TestCase):
    def test_time_command(self):
        handled, resp, action = command_router.route_command("what time is it")
        self.assertTrue(handled)
        self.assertEqual(action, "system_time")
        self.assertIn("The current time is", resp)

    @patch("automation.system_control.psutil.sensors_battery")
    def test_battery_command_with_battery(self, mock_battery):
        mock_b = MagicMock()
        mock_b.percent = 85
        mock_b.power_plugged = True
        mock_battery.return_value = mock_b

        handled, resp, action = command_router.route_command("battery status")
        self.assertTrue(handled)
        self.assertEqual(action, "system_battery")
        self.assertIn("85 percent", resp)
        self.assertIn("charging", resp)

    @patch("automation.system_control.psutil.sensors_battery")
    def test_battery_command_without_battery(self, mock_battery):
        mock_battery.return_value = None
        handled, resp, action = command_router.route_command("battery status")
        self.assertTrue(handled)
        self.assertEqual(action, "system_battery")
        self.assertIn("continuous AC power", resp)

    def test_hardware_command(self):
        handled, resp, action = command_router.route_command("cpu usage")
        self.assertTrue(handled)
        self.assertEqual(action, "system_hardware")
        self.assertIn("CPU utilization is at", resp)

    def test_web_search_command(self):
        handled, resp, action = command_router.route_command("search google for python tutorials")
        self.assertTrue(handled)
        self.assertEqual(action, "web_search_google")
        self.assertIn("Searching the web for", resp)

    def test_youtube_search_command(self):
        handled, resp, action = command_router.route_command("search youtube for lofi hip hop")
        self.assertTrue(handled)
        self.assertEqual(action, "web_search_youtube")
        self.assertIn("Searching YouTube for", resp)

    def test_unhandled_routes_to_ai(self):
        # Questions that should NOT be intercepted as automation
        handled, resp, action = command_router.route_command("What is quantum entanglement?")
        self.assertFalse(handled)
        self.assertIsNone(resp)
        self.assertIsNone(action)

if __name__ == "__main__":
    unittest.main()

