"""
Unit Tests for EV Database & Persistent Memory
"""

import unittest
from pathlib import Path
from database.database import EVDatabase

class TestEVDatabase(unittest.TestCase):
    def setUp(self):
        # Use a temporary test database
        self.test_db_path = Path(__file__).parent / "test_memory.db"
        if self.test_db_path.exists():
            try:
                self.test_db_path.unlink()
            except Exception:
                pass
        self.db = EVDatabase(self.test_db_path)
        self.db.clear_conversation_history()

    def tearDown(self):
        if self.test_db_path.exists():
            try:
                self.test_db_path.unlink()
            except Exception:
                pass

    def test_conversation_logging(self):
        self.db.add_message("user", "Hello EV")
        self.db.add_message("ev", "Greetings, Sir.")
        history = self.db.get_recent_conversation(limit=5)
        self.assertEqual(len(history), 2)
        self.assertEqual(history[0]["role"], "user")
        self.assertEqual(history[0]["content"], "Hello EV")
        self.assertEqual(history[1]["role"], "ev")

    def test_persistent_memory(self):
        self.db.set_memory("favorite_language", "Python", "preference")
        val = self.db.get_memory("favorite_language")
        self.assertEqual(val, "Python")

        memories = self.db.get_all_memories()
        self.assertTrue(any(m["key"] == "favorite_language" for m in memories))

        deleted = self.db.delete_memory("favorite_language")
        self.assertTrue(deleted)
        self.assertIsNone(self.db.get_memory("favorite_language"))

    def test_command_audit(self):
        self.db.log_command("open chrome", "app_launch", "success", "Opening Chrome")
        freq = self.db.get_frequent_commands(limit=5)
        self.assertTrue(len(freq) >= 1)
        self.assertEqual(freq[0]["raw_command"], "open chrome")

if __name__ == "__main__":
    unittest.main()

