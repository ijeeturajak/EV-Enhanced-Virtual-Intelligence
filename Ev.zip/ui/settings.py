"""
EV - Enhanced Virtual Intelligence
Settings & System Configuration Modal
"""

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QSlider, QComboBox, QCheckBox, QFrame,
    QMessageBox, QWidget
)
from PySide6.QtCore import Qt
from config import Config
from database.database import db
from core.ai_engine import ai_engine
from voice.text_to_speech import tts

class SettingsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("EV // SYSTEM CONFIGURATION MATRIX")
        self.setFixedSize(560, 680)
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowContextHelpButtonHint)

        self._init_ui()
        self._load_current_values()

    def _init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(22, 20, 22, 20)
        main_layout.setSpacing(14)

        # Header Title
        title_box = QVBoxLayout()
        title_box.setSpacing(2)
        h_title = QLabel("CORE SETTINGS // CONFIGURATION")
        h_title.setStyleSheet("font-size: 15px; font-weight: 800; color: #00f0ff; letter-spacing: 1.5px;")
        h_sub = QLabel("Configure Jenny Neural, AI credentials, speech synthesis, and preferences.")
        h_sub.setStyleSheet("font-size: 11px; color: #94a3b8;")
        title_box.addWidget(h_title)
        title_box.addWidget(h_sub)
        main_layout.addLayout(title_box)

        # 1. AI Provider Section Frame
        ai_frame = QFrame()
        ai_frame.setObjectName("panelGlass")
        ai_layout = QVBoxLayout(ai_frame)
        ai_layout.setSpacing(8)

        ai_sec_title = QLabel("AI BRAIN CREDENTIALS")
        ai_sec_title.setObjectName("panelTitle")
        ai_layout.addWidget(ai_sec_title)

        # API Key Field
        key_box = QVBoxLayout()
        key_box.setSpacing(3)
        lbl_key = QLabel("Google Gemini API Key:")
        lbl_key.setStyleSheet("font-size: 10px; color: #94a3b8;")
        self.txt_api_key = QLineEdit()
        self.txt_api_key.setEchoMode(QLineEdit.Password)
        self.txt_api_key.setPlaceholderText("Paste your Gemini API key here...")
        
        # Toggle visibility button
        h_key = QHBoxLayout()
        h_key.addWidget(self.txt_api_key)
        self.btn_show_key = QPushButton("Show")
        self.btn_show_key.setFixedWidth(55)
        self.btn_show_key.clicked.connect(self._toggle_key_visibility)
        h_key.addWidget(self.btn_show_key)

        key_box.addWidget(lbl_key)
        key_box.addLayout(h_key)
        ai_layout.addLayout(key_box)

        # Model Selector
        lbl_model = QLabel("Model Selection:")
        lbl_model.setStyleSheet("font-size: 10px; color: #94a3b8;")
        self.cmb_model = QComboBox()
        self.cmb_model.addItems(["gemini-1.5-flash", "gemini-2.0-flash", "gemini-1.5-pro"])
        self.cmb_model.setStyleSheet("background-color: #070c18; padding: 4px; border: 1px solid rgba(0, 240, 255, 0.25); border-radius: 4px; color: #fff;")
        ai_layout.addWidget(lbl_model)
        ai_layout.addWidget(self.cmb_model)

        main_layout.addWidget(ai_frame)

        # 2. Voice & Audio Section Frame (Microsoft Jenny Neural & Azure)
        voice_frame = QFrame()
        voice_frame.setObjectName("panelGlass")
        voice_layout = QVBoxLayout(voice_frame)
        voice_layout.setSpacing(8)

        v_title = QLabel("VOICE SYNTHESIS // MICROSOFT JENNY NEURAL")
        v_title.setObjectName("panelTitle")
        voice_layout.addWidget(v_title)

        # Voice Selection & Language
        h_voice_row = QHBoxLayout()
        
        box_voice = QVBoxLayout()
        lbl_voice = QLabel("Primary Voice:")
        lbl_voice.setStyleSheet("font-size: 10px; color: #94a3b8;")
        self.cmb_voice = QComboBox()
        self.cmb_voice.addItems([
            "Microsoft Jenny Neural (en-US-JennyNeural)",
            "Windows SAPI5 Fallback Voice",
            "Male (J.A.R.V.I.S. SAPI5)"
        ])
        self.cmb_voice.setStyleSheet("background-color: #070c18; padding: 4px; border: 1px solid rgba(0, 240, 255, 0.25); border-radius: 4px; color: #fff;")
        box_voice.addWidget(lbl_voice)
        box_voice.addWidget(self.cmb_voice)
        h_voice_row.addLayout(box_voice)

        box_lang = QVBoxLayout()
        lbl_lang = QLabel("Language Mode:")
        lbl_lang.setStyleSheet("font-size: 10px; color: #94a3b8;")
        self.cmb_lang = QComboBox()
        self.cmb_lang.addItems(["English (United States) - en-US"])
        self.cmb_lang.setStyleSheet("background-color: #070c18; padding: 4px; border: 1px solid rgba(0, 240, 255, 0.25); border-radius: 4px; color: #fff;")
        box_lang.addWidget(lbl_lang)
        box_lang.addWidget(self.cmb_lang)
        h_voice_row.addLayout(box_lang)

        voice_layout.addLayout(h_voice_row)

        # Optional Azure Credentials
        h_azure_row = QHBoxLayout()
        box_az_key = QVBoxLayout()
        lbl_az_key = QLabel("Azure Speech Key (Optional for Neural Voice):")
        lbl_az_key.setStyleSheet("font-size: 10px; color: #94a3b8;")
        self.txt_az_key = QLineEdit()
        self.txt_az_key.setEchoMode(QLineEdit.Password)
        self.txt_az_key.setPlaceholderText("Azure Speech key or leave blank for Windows voice")
        box_az_key.addWidget(lbl_az_key)
        box_az_key.addWidget(self.txt_az_key)
        h_azure_row.addLayout(box_az_key, stretch=3)

        box_az_reg = QVBoxLayout()
        lbl_az_reg = QLabel("Region:")
        lbl_az_reg.setStyleSheet("font-size: 10px; color: #94a3b8;")
        self.txt_az_reg = QLineEdit()
        self.txt_az_reg.setPlaceholderText("e.g. eastus")
        box_az_reg.addWidget(lbl_az_reg)
        box_az_reg.addWidget(self.txt_az_reg)
        h_azure_row.addLayout(box_az_reg, stretch=1)

        voice_layout.addLayout(h_azure_row)

        # Speech Rate Slider (WPM)
        box_rate = QVBoxLayout()
        box_rate.setSpacing(2)
        self.lbl_rate_val = QLabel(f"Speaking Rate: {Config.VOICE_RATE} WPM (Moderate)")
        self.lbl_rate_val.setStyleSheet("font-size: 10px; color: #94a3b8;")
        self.slider_rate = QSlider(Qt.Horizontal)
        self.slider_rate.setRange(120, 240)
        self.slider_rate.setValue(Config.VOICE_RATE)
        self.slider_rate.valueChanged.connect(self._on_rate_slider_changed)
        box_rate.addWidget(self.lbl_rate_val)
        box_rate.addWidget(self.slider_rate)
        voice_layout.addLayout(box_rate)

        # Volume Slider
        box_vol = QVBoxLayout()
        box_vol.setSpacing(2)
        self.lbl_vol_val = QLabel(f"Speaking Volume: {int(Config.VOICE_VOLUME * 100)}%")
        self.lbl_vol_val.setStyleSheet("font-size: 10px; color: #94a3b8;")
        self.slider_vol = QSlider(Qt.Horizontal)
        self.slider_vol.setRange(10, 100)
        self.slider_vol.setValue(int(Config.VOICE_VOLUME * 100))
        self.slider_vol.valueChanged.connect(lambda v: self.lbl_vol_val.setText(f"Speaking Volume: {v}%"))
        box_vol.addWidget(self.lbl_vol_val)
        box_vol.addWidget(self.slider_vol)
        voice_layout.addLayout(box_vol)

        main_layout.addWidget(voice_frame)

        # 3. Behavior & Memory
        behavior_frame = QFrame()
        behavior_frame.setObjectName("panelGlass")
        beh_layout = QVBoxLayout(behavior_frame)
        beh_layout.setSpacing(6)

        beh_title = QLabel("BEHAVIOR & MEMORY")
        beh_title.setObjectName("panelTitle")
        beh_layout.addWidget(beh_title)

        self.chk_continuous = QCheckBox("Continuous Ambient Listening ('Hey EV')")
        self.chk_continuous.setChecked(Config.CONTINUOUS_LISTENING)
        beh_layout.addWidget(self.chk_continuous)

        btn_clear_history = QPushButton("Clear Conversation History")
        btn_clear_history.setObjectName("btnStop")
        btn_clear_history.clicked.connect(self._clear_history)
        beh_layout.addWidget(btn_clear_history)

        main_layout.addWidget(behavior_frame)

        # Bottom Action Buttons (Cancel, Save)
        h_actions = QHBoxLayout()
        btn_cancel = QPushButton("Cancel")
        btn_cancel.clicked.connect(self.reject)
        
        btn_save = QPushButton("Save Matrix Settings")
        btn_save.setObjectName("btnSend")
        btn_save.clicked.connect(self._save_settings)

        h_actions.addStretch()
        h_actions.addWidget(btn_cancel)
        h_actions.addWidget(btn_save)
        main_layout.addLayout(h_actions)

    def _on_rate_slider_changed(self, v: int):
        speed_label = "Moderate" if 160 <= v <= 190 else ("Fast" if v > 190 else "Slow")
        self.lbl_rate_val.setText(f"Speaking Rate: {v} WPM ({speed_label})")

    def _toggle_key_visibility(self):
        if self.txt_api_key.echoMode() == QLineEdit.Password:
            self.txt_api_key.setEchoMode(QLineEdit.Normal)
            self.btn_show_key.setText("Hide")
        else:
            self.txt_api_key.setEchoMode(QLineEdit.Password)
            self.btn_show_key.setText("Show")

    def _load_current_values(self):
        self.txt_api_key.setText(Config.GEMINI_API_KEY)
        self.cmb_model.setCurrentText(Config.AI_MODEL)
        self.txt_az_key.setText(Config.AZURE_SPEECH_KEY)
        self.txt_az_reg.setText(Config.AZURE_SPEECH_REGION or "eastus")

        if Config.VOICE_NAME == "en-US-JennyNeural":
            self.cmb_voice.setCurrentIndex(0)
        elif Config.VOICE_GENDER == "male":
            self.cmb_voice.setCurrentIndex(2)
        else:
            self.cmb_voice.setCurrentIndex(1)

        self.cmb_lang.setCurrentIndex(0)
        self.slider_rate.setValue(Config.VOICE_RATE)
        self.slider_vol.setValue(int(Config.VOICE_VOLUME * 100))
        self.chk_continuous.setChecked(Config.CONTINUOUS_LISTENING)

    def _save_settings(self):
        new_key = self.txt_api_key.text().strip()
        new_model = self.cmb_model.currentText()
        new_az_key = self.txt_az_key.text().strip()
        new_az_reg = self.txt_az_reg.text().strip() or "eastus"

        voice_idx = self.cmb_voice.currentIndex()
        if voice_idx == 0:
            new_voice = "en-US-JennyNeural"
            new_gender = "female"
        elif voice_idx == 2:
            new_voice = "male"
            new_gender = "male"
        else:
            new_voice = "female"
            new_gender = "female"

        new_lang = "en-US"
        new_rate = self.slider_rate.value()
        new_vol = round(self.slider_vol.value() / 100.0, 2)
        new_continuous = self.chk_continuous.isChecked()

        # Update runtime and persist to .env
        ai_engine.update_key(new_key)
        Config.update_setting("AI_MODEL", new_model)
        Config.update_setting("AZURE_SPEECH_KEY", new_az_key)
        Config.update_setting("AZURE_SPEECH_REGION", new_az_reg)
        Config.update_setting("VOICE_NAME", new_voice)
        Config.update_setting("VOICE_GENDER", new_gender)
        Config.update_setting("LANGUAGE", new_lang)
        Config.update_setting("VOICE_RATE", str(new_rate))
        Config.update_setting("VOICE_VOLUME", str(new_vol))
        Config.update_setting("CONTINUOUS_LISTENING", str(new_continuous).lower())

        # Re-initialize TTS synthesizer with new settings
        tts._init_azure()
        tts._init_pyttsx3()

        QMessageBox.information(self, "EV Configuration", "Settings updated and saved successfully.")
        self.accept()

    def _clear_history(self):
        reply = QMessageBox.question(
            self,
            "Clear History",
            "Are you certain you wish to purge all stored conversation history?",
            QMessageBox.Yes | QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            db.clear_conversation_history()
            QMessageBox.information(self, "History Purged", "All conversation history has been erased.")
