"""
EV - Enhanced Virtual Intelligence
Main Futuristic J.A.R.V.I.S. Desktop Dashboard
"""

from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QLineEdit, QScrollArea, QFrame, QSizePolicy,
    QApplication
)
from PySide6.QtCore import Qt, QTimer, QPoint
from PySide6.QtGui import QIcon, QFont

from ui.components import EVCentralCore, ChatBubble, TelemetryGauge
from ui.settings import SettingsDialog
from ui.styles import QSS_STYLE
from config import Config
from core.events import event_bus
from core.assistant import assistant
from database.database import db
from automation.system_control import system_control

class EVDashboard(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("EV — Enhanced Virtual Intelligence")
        self.setMinimumSize(1150, 750)
        self.resize(1240, 800)

        # Frameless window with custom title bar
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Window)
        self.setAttribute(Qt.WA_TranslucentBackground, False)

        # Dragging variables for frameless window
        self._drag_pos = QPoint()

        # Apply global stylesheet
        self.setStyleSheet(QSS_STYLE)

        self._init_ui()
        self._connect_signals()
        self._load_initial_chat_history()
        self._start_telemetry_loop()

    def _init_ui(self):
        central_widget = QWidget(self)
        self.setCentralWidget(central_widget)

        root_layout = QVBoxLayout(central_widget)
        root_layout.setContentsMargins(1, 1, 1, 1)
        root_layout.setSpacing(0)

        # 1. Custom Futuristic Header Bar
        header = self._create_header_bar()
        root_layout.addWidget(header)

        # 2. Main Content Grid (Left Panel, Center Core, Right Telemetry)
        main_content = QWidget()
        content_layout = QHBoxLayout(main_content)
        content_layout.setContentsMargins(14, 14, 14, 10)
        content_layout.setSpacing(14)

        # Left: Chat History & Quick Actions
        left_panel = self._create_left_panel()
        content_layout.addWidget(left_panel, stretch=3)

        # Center: Arc Reactor Core
        center_panel = self._create_center_panel()
        content_layout.addWidget(center_panel, stretch=4)

        # Right: Hardware Telemetry
        right_panel = self._create_right_panel()
        content_layout.addWidget(right_panel, stretch=3)

        root_layout.addWidget(main_content, stretch=1)

        # 3. Bottom Controls (Mic, Input, Send, Stop)
        bottom_bar = self._create_bottom_bar()
        root_layout.addWidget(bottom_bar)

    def _create_header_bar(self) -> QFrame:
        header = QFrame()
        header.setObjectName("headerBar")
        header.setFixedHeight(48)
        layout = QHBoxLayout(header)
        layout.setContentsMargins(16, 0, 16, 0)
        layout.setSpacing(12)

        # EV Logo
        lbl_icon = QLabel("⚡")
        lbl_icon.setStyleSheet("font-size: 18px; color: #00f0ff;")
        layout.addWidget(lbl_icon)

        # Title & Subtitle
        title_box = QVBoxLayout()
        title_box.setSpacing(0)
        title_box.setAlignment(Qt.AlignVCenter)
        
        lbl_title = QLabel("EV // ENHANCED VIRTUAL INTELLIGENCE")
        lbl_title.setObjectName("titleLabel")
        lbl_sub = QLabel(f"AUTONOMOUS DESKTOP PROTOCOL // VER {Config.VERSION}")
        lbl_sub.setObjectName("subtitleLabel")
        
        title_box.addWidget(lbl_title)
        title_box.addWidget(lbl_sub)
        layout.addLayout(title_box)

        layout.addStretch()

        # Assistant Status Pill
        self.status_pill = QLabel("● ONLINE")
        self.status_pill.setStyleSheet("""
            background-color: rgba(16, 185, 129, 0.15);
            border: 1px solid #10b981;
            color: #34d399;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 700;
            font-family: 'Consolas', monospace;
        """)
        layout.addWidget(self.status_pill)

        # Settings Button
        btn_settings = QPushButton("⚙ CONFIG")
        btn_settings.setFixedHeight(28)
        btn_settings.clicked.connect(self._open_settings)
        layout.addWidget(btn_settings)

        # Window Controls (Min, Max, Close)
        btn_min = QPushButton("—")
        btn_min.setFixedSize(28, 28)
        btn_min.clicked.connect(self.showMinimized)
        layout.addWidget(btn_min)

        btn_max = QPushButton("□")
        btn_max.setFixedSize(28, 28)
        btn_max.clicked.connect(self._toggle_maximize)
        layout.addWidget(btn_max)

        btn_close = QPushButton("✕")
        btn_close.setFixedSize(28, 28)
        btn_close.setObjectName("btnStop")
        btn_close.clicked.connect(self.close)
        layout.addWidget(btn_close)

        return header

    def _create_left_panel(self) -> QFrame:
        panel = QFrame()
        panel.setObjectName("panelGlass")
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(10)

        # Header Title
        title = QLabel("CONVERSATION AUDIT TAPE")
        title.setObjectName("panelTitle")
        layout.addWidget(title)

        # Scrollable Chat History Area
        self.chat_scroll = QScrollArea()
        self.chat_scroll.setWidgetResizable(True)
        self.chat_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        
        self.chat_container = QWidget()
        self.chat_layout = QVBoxLayout(self.chat_container)
        self.chat_layout.setContentsMargins(4, 4, 4, 4)
        self.chat_layout.setSpacing(8)
        self.chat_layout.addStretch()

        self.chat_scroll.setWidget(self.chat_container)
        layout.addWidget(self.chat_scroll, stretch=1)

        # Quick Voice Action Chips
        chips_title = QLabel("QUICK DIRECTIVES:")
        chips_title.setStyleSheet("font-size: 10px; font-weight: 700; font-family: 'Consolas', monospace; color: #94a3b8;")
        layout.addWidget(chips_title)

        chips_layout = QVBoxLayout()
        chips_layout.setSpacing(4)
        
        quick_commands = [
            ("⚡ Open Visual Studio Code", "open visual studio code"),
            ("🌐 Search Python Tutorials", "search google for best python tutorials"),
            ("📊 System Hardware Report", "system report"),
            ("▶ Open YouTube", "open youtube"),
            ("🔋 Check Battery Status", "battery status")
        ]

        for label_text, cmd_text in quick_commands:
            btn = QPushButton(label_text)
            btn.setObjectName("chipAction")
            btn.clicked.connect(lambda checked=False, c=cmd_text: self._execute_quick_command(c))
            chips_layout.addWidget(btn)

        layout.addLayout(chips_layout)
        return panel

    def _create_center_panel(self) -> QFrame:
        panel = QFrame()
        panel.setObjectName("panelGlass")
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(6)

        # Header Badge
        header_row = QHBoxLayout()
        lbl_core = QLabel("PRIMARY ARC REACTOR // AI CORE")
        lbl_core.setObjectName("panelTitle")
        header_row.addWidget(lbl_core)
        header_row.addStretch()
        
        self.lbl_mic_status = QLabel("WAKE: 'HEY EV'")
        self.lbl_mic_status.setStyleSheet("font-size: 10px; color: #00f0ff; font-family: 'Consolas', monospace;")
        header_row.addWidget(self.lbl_mic_status)
        layout.addLayout(header_row)

        # Central Arc Reactor / AI Core
        self.ai_core = EVCentralCore()
        layout.addWidget(self.ai_core, stretch=1)

        return panel

    def _create_right_panel(self) -> QFrame:
        panel = QFrame()
        panel.setObjectName("panelGlass")
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(12)

        # Panel Header
        p_title = QLabel("SYSTEM TELEMETRY")
        p_title.setObjectName("panelTitle")
        layout.addWidget(p_title)

        # Clock & Date Card
        clock_card = QFrame()
        clock_card.setStyleSheet("background-color: rgba(7, 12, 24, 0.8); border: 1px solid rgba(0, 240, 255, 0.2); border-radius: 6px; padding: 10px;")
        clock_layout = QVBoxLayout(clock_card)
        clock_layout.setContentsMargins(8, 6, 8, 6)
        clock_layout.setSpacing(2)

        self.lbl_clock = QLabel("00:00:00 AM")
        self.lbl_clock.setStyleSheet("font-size: 22px; font-weight: 800; font-family: 'Consolas', monospace; color: #00f0ff;")
        self.lbl_date = QLabel("Loading date...")
        self.lbl_date.setStyleSheet("font-size: 11px; color: #94a3b8;")

        clock_layout.addWidget(self.lbl_clock)
        clock_layout.addWidget(self.lbl_date)
        layout.addWidget(clock_card)

        # Hardware Telemetry Gauges
        self.cpu_gauge = TelemetryGauge("CPU UTILIZATION")
        layout.addWidget(self.cpu_gauge)

        self.ram_gauge = TelemetryGauge("MEMORY (RAM) LOAD")
        layout.addWidget(self.ram_gauge)

        self.battery_gauge = TelemetryGauge("POWER / BATTERY")
        layout.addWidget(self.battery_gauge)

        # Network Status Card
        self.net_card = QFrame()
        self.net_card.setStyleSheet("background-color: rgba(7, 12, 24, 0.8); border: 1px solid rgba(0, 240, 255, 0.2); border-radius: 6px; padding: 8px;")
        net_layout = QHBoxLayout(self.net_card)
        net_layout.setContentsMargins(8, 6, 8, 6)

        net_label = QLabel("NETWORK UPLINK:")
        net_label.setStyleSheet("font-size: 11px; color: #94a3b8;")
        self.net_status = QLabel("ONLINE")
        self.net_status.setStyleSheet("font-size: 11px; font-weight: 700; color: #10b981; font-family: 'Consolas', monospace;")
        
        net_layout.addWidget(net_label)
        net_layout.addStretch()
        net_layout.addWidget(self.net_status)
        layout.addWidget(self.net_card)

        layout.addStretch()
        return panel

    def _create_bottom_bar(self) -> QFrame:
        bar = QFrame()
        bar.setObjectName("headerBar")
        bar.setFixedHeight(64)
        layout = QHBoxLayout(bar)
        layout.setContentsMargins(16, 10, 16, 10)
        layout.setSpacing(10)

        # Microphone Toggle Button
        self.btn_mic = QPushButton("🎙 MIC ON")
        self.btn_mic.setObjectName("btnMicActive")
        self.btn_mic.setFixedSize(110, 42)
        self.btn_mic.clicked.connect(self._toggle_mic)
        layout.addWidget(self.btn_mic)

        # Text Command Input Field
        self.input_field = QLineEdit()
        self.input_field.setPlaceholderText("Say 'Hey EV' or type a command / query here...")
        self.input_field.returnPressed.connect(self._send_text_command)
        self.input_field.setFixedHeight(42)
        layout.addWidget(self.input_field, stretch=1)

        # Send Button
        btn_send = QPushButton("⚡ SEND")
        btn_send.setObjectName("btnSend")
        btn_send.setFixedHeight(42)
        btn_send.clicked.connect(self._send_text_command)
        layout.addWidget(btn_send)

        # Stop Speaking Button
        btn_stop = QPushButton("⏹ STOP")
        btn_stop.setObjectName("btnStop")
        btn_stop.setFixedHeight(42)
        btn_stop.clicked.connect(assistant.stop_speaking)
        layout.addWidget(btn_stop)

        return bar

    # --- Window Dragging Logic for Frameless Window ---

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event):
        if event.buttons() == Qt.LeftButton and not self.isMaximized():
            self.move(event.globalPosition().toPoint() - self._drag_pos)
            event.accept()

    def _toggle_maximize(self):
        if self.isMaximized():
            self.showNormal()
        else:
            self.showMaximized()

    # --- Core Wiring & Signal Handlers ---

    def _connect_signals(self):
        event_bus.state_changed.connect(self._on_state_changed)
        event_bus.message_received.connect(self._on_message_received)
        event_bus.telemetry_updated.connect(self._on_telemetry_updated)
        event_bus.error_occurred.connect(self._on_error_occurred)

    def _on_state_changed(self, new_state: str):
        self.ai_core.set_state(new_state)

        styles = {
            "IDLE": ("● ONLINE", "rgba(16, 185, 129, 0.15)", "#10b981", "#34d399"),
            "LISTENING": ("◉ LISTENING", "rgba(0, 240, 255, 0.25)", "#00f0ff", "#00f0ff"),
            "THINKING": ("⚙ PROCESSING", "rgba(245, 158, 11, 0.2)", "#f59e0b", "#fbbf24"),
            "SPEAKING": ("🔊 SPEAKING", "rgba(56, 189, 248, 0.2)", "#38bdf8", "#38bdf8"),
            "MUTED": ("✕ MUTED", "rgba(244, 63, 94, 0.2)", "#f43f5e", "#fb7185")
        }

        text, bg, border, color = styles.get(new_state, ("● STANDBY", "#070b14", "#1e293b", "#94a3b8"))
        self.status_pill.setText(text)
        self.status_pill.setStyleSheet(f"""
            background-color: {bg};
            border: 1px solid {border};
            color: {color};
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 700;
            font-family: 'Consolas', monospace;
        """)

    def _on_message_received(self, role: str, content: str):
        bubble = ChatBubble(role, content)
        # Insert before the stretch item
        self.chat_layout.insertWidget(self.chat_layout.count() - 1, bubble)
        # Auto-scroll to bottom
        QTimer.singleShot(50, lambda: self.chat_scroll.verticalScrollBar().setValue(
            self.chat_scroll.verticalScrollBar().maximum()
        ))

    def _on_error_occurred(self, err_msg: str):
        self.status_pill.setText(f"⚠ {err_msg[:14]}")

    def _load_initial_chat_history(self):
        recent = db.get_recent_conversation(limit=15)
        for msg in recent:
            bubble = ChatBubble(msg["role"], msg["content"])
            self.chat_layout.insertWidget(self.chat_layout.count() - 1, bubble)

    def _start_telemetry_loop(self):
        self.telemetry_timer = QTimer(self)
        self.telemetry_timer.timeout.connect(self._poll_telemetry)
        self.telemetry_timer.start(1000)
        self._poll_telemetry()

    def _poll_telemetry(self):
        data = system_control.get_system_telemetry()
        self._on_telemetry_updated(data)

    def _on_telemetry_updated(self, data: dict):
        self.lbl_clock.setText(data["time_str"])
        self.lbl_date.setText(data["date_str"])
        self.cpu_gauge.update_val(data["cpu_percent"])
        self.ram_gauge.update_val(data["ram_percent"], f"{data['ram_used_gb']} GB / {data['ram_total_gb']} GB")
        
        bat = data["battery"]
        bat_sub = "Charging" if bat["power_plugged"] else "On Battery"
        self.battery_gauge.update_val(bat["percent"], bat_sub)

        if data["online"]:
            self.net_status.setText("ONLINE // 1.1.1.1")
            self.net_status.setStyleSheet("font-size: 11px; font-weight: 700; color: #10b981; font-family: 'Consolas', monospace;")
        else:
            self.net_status.setText("OFFLINE")
            self.net_status.setStyleSheet("font-size: 11px; font-weight: 700; color: #f43f5e; font-family: 'Consolas', monospace;")

    # --- Actions ---

    def _send_text_command(self):
        text = self.input_field.text().strip()
        if not text:
            return
        self.input_field.clear()
        assistant.process_command_async(text)

    def _execute_quick_command(self, cmd_text: str):
        assistant.process_command_async(cmd_text)

    def _toggle_mic(self):
        is_muted = assistant.toggle_mic()
        if is_muted:
            self.btn_mic.setText("🔇 MUTED")
            self.btn_mic.setObjectName("btnMicMuted")
        else:
            self.btn_mic.setText("🎙 MIC ON")
            self.btn_mic.setObjectName("btnMicActive")
        self.btn_mic.setStyle(self.btn_mic.style())

    def _open_settings(self):
        dlg = SettingsDialog(self)
        dlg.exec()

