"""
EV - Enhanced Virtual Intelligence
Futuristic UI Components & Arc Reactor / EV Core Widget
"""

import math
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QProgressBar,
    QFrame, QScrollArea, QSizePolicy
)
from PySide6.QtCore import Qt, QTimer, QRectF, QPointF
from PySide6.QtGui import (
    QPainter, QColor, QPen, QBrush, QRadialGradient,
    QLinearGradient, QFont
)

class EVCentralCore(QWidget):
    """
    Futuristic Animated Arc Reactor & Holographic Core
    States: IDLE, LISTENING, THINKING, SPEAKING, MUTED
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(320, 320)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        # Animation states
        self.angle_outer = 0.0
        self.angle_inner = 0.0
        self.pulse_phase = 0.0
        self.state = "IDLE"
        self.status_text = "SYSTEM ONLINE // LISTENING FOR 'HEY EV'"

        # Color schemes by state
        self.colors = {
            "IDLE": QColor(0, 240, 255),       # Cyan
            "LISTENING": QColor(16, 185, 129),  # Emerald
            "THINKING": QColor(245, 158, 11),   # Amber
            "SPEAKING": QColor(56, 189, 248),   # Blue / Cyan
            "MUTED": QColor(244, 63, 94)        # Crimson
        }

        # 60 FPS animation timer
        self.anim_timer = QTimer(self)
        self.anim_timer.timeout.connect(self._update_animation)
        self.anim_timer.start(16)

    def set_state(self, new_state: str):
        self.state = new_state
        state_labels = {
            "IDLE": "SYSTEM ONLINE // AWAITING COMMAND",
            "LISTENING": "LISTENING ACTIVE // SPEAK NOW",
            "THINKING": "AI BRAIN ENGAGED // PROCESSING",
            "SPEAKING": "TRANSMITTING RESPONSE...",
            "MUTED": "MICROPHONE MUTED // STANDBY"
        }
        self.status_text = state_labels.get(new_state, "STANDBY")
        self.update()

    def _update_animation(self):
        # Rotation speeds
        speed_mult = 2.5 if self.state == "THINKING" else (1.8 if self.state == "SPEAKING" else 1.0)
        self.angle_outer = (self.angle_outer + 0.8 * speed_mult) % 360.0
        self.angle_inner = (self.angle_inner - 1.2 * speed_mult) % 360.0
        self.pulse_phase = (self.pulse_phase + 0.05 * speed_mult) % (2 * math.pi)
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        width = self.width()
        height = self.height()
        center = QPointF(width / 2.0, height / 2.0)
        radius = min(width, height) / 2.0 - 20

        primary_color = self.colors.get(self.state, QColor(0, 240, 255))

        # 1. Outer Holographic Glow Background
        bg_glow = QRadialGradient(center, radius)
        glow_color = QColor(primary_color)
        glow_color.setAlpha(35)
        bg_glow.setColorAt(0.0, glow_color)
        bg_glow.setColorAt(0.7, QColor(0, 0, 0, 0))
        painter.fillRect(self.rect(), QBrush(bg_glow))

        # 2. Outer Rotating Segmented Ring
        painter.save()
        painter.translate(center)
        painter.rotate(self.angle_outer)

        pen_outer = QPen(primary_color, 2.0)
        painter.setPen(pen_outer)
        r_outer = radius * 0.88

        # Draw 12 curved arc segments with ticks
        for i in range(12):
            start_ang = i * 30
            painter.drawArc(QRectF(-r_outer, -r_outer, r_outer * 2, r_outer * 2), start_ang * 16, 18 * 16)
        painter.restore()

        # 3. Middle Counter-Rotating Dial Ring with Ticks
        painter.save()
        painter.translate(center)
        painter.rotate(self.angle_inner)

        r_mid = radius * 0.72
        pen_mid = QPen(QColor(primary_color.red(), primary_color.green(), primary_color.blue(), 160), 1.2)
        painter.setPen(pen_mid)
        painter.drawEllipse(QRectF(-r_mid, -r_mid, r_mid * 2, r_mid * 2))

        # Dial Tick Marks
        for i in range(36):
            tick_len = 6 if i % 3 == 0 else 3
            ang = math.radians(i * 10)
            p1 = QPointF(math.cos(ang) * (r_mid - tick_len), math.sin(ang) * (r_mid - tick_len))
            p2 = QPointF(math.cos(ang) * r_mid, math.sin(ang) * r_mid)
            painter.drawLine(p1, p2)
        painter.restore()

        # 4. Audio-Reactive Waveforms (Active when speaking or listening)
        if self.state in ["SPEAKING", "LISTENING"]:
            painter.save()
            painter.translate(center)
            wave_pen = QPen(primary_color, 1.8)
            painter.setPen(wave_pen)

            r_wave = radius * 0.52
            wave_points = []
            steps = 48
            for i in range(steps + 1):
                ang = (i / steps) * 2 * math.pi
                # Sine wave ripple based on angle & phase
                amp = 8.0 * math.sin(ang * 6 + self.pulse_phase * 3)
                r_cur = r_wave + amp
                wave_points.append(QPointF(math.cos(ang) * r_cur, math.sin(ang) * r_cur))
            
            for i in range(len(wave_points) - 1):
                painter.drawLine(wave_points[i], wave_points[i + 1])
            painter.restore()

        # 5. Pulsating Arc Reactor Core
        pulse_scale = 1.0 + 0.08 * math.sin(self.pulse_phase)
        r_core = (radius * 0.32) * pulse_scale

        core_grad = QRadialGradient(center, r_core)
        core_bright = QColor(255, 255, 255, 240)
        core_mid = QColor(primary_color.red(), primary_color.green(), primary_color.blue(), 180)
        core_edge = QColor(primary_color.red(), primary_color.green(), primary_color.blue(), 0)

        core_grad.setColorAt(0.0, core_bright)
        core_grad.setColorAt(0.45, core_mid)
        core_grad.setColorAt(1.0, core_edge)

        painter.setBrush(QBrush(core_grad))
        painter.setPen(Qt.NoPen)
        painter.drawEllipse(center, r_core, r_core)

        # 6. Central Reactor Triangular / Hex Insignia
        painter.save()
        painter.translate(center)
        insignia_pen = QPen(QColor(255, 255, 255, 200), 1.5)
        painter.setPen(insignia_pen)
        r_inner_tri = radius * 0.12
        for i in range(3):
            ang = math.radians(i * 120 + 90)
            ang_next = math.radians((i + 1) * 120 + 90)
            p1 = QPointF(math.cos(ang) * r_inner_tri, math.sin(ang) * r_inner_tri)
            p2 = QPointF(math.cos(ang_next) * r_inner_tri, math.sin(ang_next) * r_inner_tri)
            painter.drawLine(p1, p2)
        painter.restore()

        # 7. Status HUD Text beneath Core
        painter.setPen(QColor(primary_color.red(), primary_color.green(), primary_color.blue(), 220))
        painter.setFont(QFont("Consolas", 9, QFont.Bold))
        text_rect = QRectF(0, height - 35, width, 25)
        painter.drawText(text_rect, Qt.AlignCenter, self.status_text)


class ChatBubble(QFrame):
    """Futuristic conversational chat message bubble."""
    def __init__(self, role: str, text: str, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(4)

        is_user = role == "user"
        
        # Header Label (Name & Icon)
        header_text = "👤 USER" if is_user else "⚡ EV"
        header_color = "#94a3b8" if is_user else "#00f0ff"
        
        header_label = QLabel(header_text)
        header_label.setStyleSheet(f"font-size: 10px; font-weight: 700; font-family: 'Consolas', monospace; color: {header_color};")
        layout.addWidget(header_label)

        # Message Content
        content_label = QLabel(text)
        content_label.setWordWrap(True)
        content_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        content_label.setStyleSheet("font-size: 13px; color: #f8fafc; line-height: 1.4;")
        layout.addWidget(content_label)

        # Bubble Background Frame Style
        if is_user:
            self.setStyleSheet("""
                QFrame {
                    background-color: rgba(30, 41, 59, 0.6);
                    border: 1px solid rgba(148, 163, 184, 0.2);
                    border-radius: 8px;
                }
            """)
        else:
            self.setStyleSheet("""
                QFrame {
                    background-color: rgba(13, 27, 49, 0.7);
                    border: 1px solid rgba(0, 240, 255, 0.35);
                    border-radius: 8px;
                }
            """)


class TelemetryGauge(QFrame):
    """System Hardware Gauge display card."""
    def __init__(self, title: str, unit: str = "%", parent=None):
        super().__init__(parent)
        self.setObjectName("panelGlass")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(6)

        # Header Title
        title_lbl = QLabel(title)
        title_lbl.setObjectName("metricLabel")
        layout.addWidget(title_lbl)

        # Big Number Value
        self.value_lbl = QLabel(f"0{unit}")
        self.value_lbl.setObjectName("metricValue")
        layout.addWidget(self.value_lbl)

        # Progress Indicator Bar
        self.bar = QProgressBar()
        self.bar.setRange(0, 100)
        self.bar.setValue(0)
        self.bar.setTextVisible(False)
        layout.addWidget(self.bar)

        self.unit = unit

    def update_val(self, val: float, subtitle: str = ""):
        self.value_lbl.setText(f"{int(val)}{self.unit}")
        self.bar.setValue(int(val))
        if subtitle:
            self.value_lbl.setToolTip(subtitle)

