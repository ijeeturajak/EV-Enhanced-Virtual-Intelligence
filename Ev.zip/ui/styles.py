"""
EV - Enhanced Virtual Intelligence
Futuristic J.A.R.V.I.S. Neon Cyan & Deep Navy Stylesheet
"""

QSS_STYLE = """
/* Global Window Styling */
QMainWindow, QDialog {
    background-color: #050811;
    color: #e2e8f0;
    font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif;
    border: 1px solid rgba(0, 240, 255, 0.25);
    border-radius: 12px;
}

QWidget {
    color: #e2e8f0;
    font-family: 'Segoe UI', sans-serif;
}

/* Custom Glass Panels */
QFrame#panelGlass {
    background-color: rgba(13, 20, 36, 0.75);
    border: 1px solid rgba(0, 240, 255, 0.2);
    border-radius: 10px;
}

QFrame#headerBar {
    background-color: rgba(8, 12, 22, 0.95);
    border-bottom: 1px solid rgba(0, 240, 255, 0.25);
    border-top-left-radius: 12px;
    border-top-right-radius: 12px;
}

/* Typography & Labels */
QLabel#titleLabel {
    font-size: 16px;
    font-weight: 800;
    color: #ffffff;
    letter-spacing: 2px;
}

QLabel#subtitleLabel {
    font-size: 11px;
    font-family: 'Consolas', 'Courier New', monospace;
    color: #00f0ff;
    letter-spacing: 1px;
}

QLabel#panelTitle {
    font-size: 12px;
    font-weight: 700;
    font-family: 'Consolas', monospace;
    color: #38bdf8;
    letter-spacing: 1.5px;
    text-transform: uppercase;
}

QLabel#metricValue {
    font-size: 20px;
    font-weight: 700;
    font-family: 'Consolas', monospace;
    color: #ffffff;
}

QLabel#metricLabel {
    font-size: 11px;
    color: #94a3b8;
    font-family: 'Segoe UI', sans-serif;
}

/* Futuristic Neon Buttons */
QPushButton {
    background-color: #0d1a2d;
    border: 1px solid rgba(0, 240, 255, 0.3);
    border-radius: 6px;
    color: #f1f5f9;
    padding: 8px 14px;
    font-size: 12px;
    font-weight: 600;
    font-family: 'Segoe UI', sans-serif;
}

QPushButton:hover {
    background-color: rgba(0, 240, 255, 0.15);
    border-color: #00f0ff;
    color: #ffffff;
}

QPushButton:pressed {
    background-color: rgba(0, 240, 255, 0.3);
}

QPushButton#btnSend {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #0284c7, stop:1 #00f0ff);
    color: #030712;
    border: none;
    font-weight: 700;
    padding: 8px 20px;
}

QPushButton#btnSend:hover {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #38bdf8, stop:1 #67e8f9);
}

QPushButton#btnMicActive {
    background-color: rgba(16, 185, 129, 0.2);
    border: 1px solid #10b981;
    color: #34d399;
    border-radius: 20px;
}

QPushButton#btnMicMuted {
    background-color: rgba(244, 63, 94, 0.2);
    border: 1px solid #f43f5e;
    color: #fb7185;
    border-radius: 20px;
}

QPushButton#btnStop {
    background-color: rgba(244, 63, 94, 0.15);
    border: 1px solid rgba(244, 63, 94, 0.4);
    color: #fda4af;
}

QPushButton#btnStop:hover {
    background-color: rgba(244, 63, 94, 0.35);
    color: #ffffff;
}

/* Quick Action Chips */
QPushButton#chipAction {
    background-color: rgba(255, 255, 255, 0.03);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 12px;
    font-size: 11px;
    color: #94a3b8;
    padding: 5px 10px;
    text-align: left;
}

QPushButton#chipAction:hover {
    background-color: rgba(0, 240, 255, 0.1);
    border-color: rgba(0, 240, 255, 0.4);
    color: #38bdf8;
}

/* Text Inputs */
QLineEdit {
    background-color: #070c18;
    border: 1px solid rgba(0, 240, 255, 0.25);
    border-radius: 6px;
    padding: 9px 14px;
    color: #ffffff;
    font-size: 13px;
    selection-background-color: #0284c7;
}

QLineEdit:focus {
    border: 1px solid #00f0ff;
    background-color: #0a1122;
}

/* Scroll Areas */
QScrollArea {
    border: none;
    background-color: transparent;
}

QScrollBar:vertical {
    border: none;
    background: #090e1a;
    width: 6px;
    margin: 0;
}

QScrollBar::handle:vertical {
    background: #1e293b;
    min-height: 20px;
    border-radius: 3px;
}

QScrollBar::handle:vertical:hover {
    background: #00f0ff;
}

QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0px;
}

/* Sliders */
QSlider::groove:horizontal {
    border: 1px solid #1e293b;
    height: 6px;
    background: #090e1a;
    border-radius: 3px;
}

QSlider::sub-page:horizontal {
    background: #00f0ff;
    border-radius: 3px;
}

QSlider::handle:horizontal {
    background: #ffffff;
    border: 2px solid #00f0ff;
    width: 14px;
    margin-top: -5px;
    margin-bottom: -5px;
    border-radius: 7px;
}

/* Progress Bars */
QProgressBar {
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 4px;
    background-color: #070c18;
    height: 8px;
    text-align: right;
}

QProgressBar::chunk {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #0284c7, stop:1 #00f0ff);
    border-radius: 3px;
}
"""

