"""
EV - Enhanced Virtual Intelligence
Allowlisted Command Router & Automation Dispatcher
"""

import re
import logging
from typing import Tuple, Optional
from automation.app_launcher import app_launcher
from automation.browser import browser
from automation.file_manager import file_manager
from automation.system_control import system_control

logger = logging.getLogger("EV.CommandRouter")

class CommandRouter:
    def __init__(self):
        pass

    def route_command(self, raw_text: str) -> Tuple[bool, Optional[str], Optional[str]]:
        """
        Evaluate user command against allowlisted automation patterns.
        Returns:
            (is_handled: bool, voice_response: str, action_type: str)
        """
        if not raw_text:
            return False, None, None

        cmd = raw_text.lower().strip()

        # 1. System Telemetry & Time/Date
        if any(p in cmd for p in ["what time is it", "current time", "tell me the time", "time please"]):
            resp = system_control.get_time_report()
            return True, resp, "system_time"

        if any(p in cmd for p in ["today's date", "what is the date", "current date", "what day is it"]):
            telemetry = system_control.get_system_telemetry()
            return True, f"Today is {telemetry['date_str']}.", "system_date"

        if any(p in cmd for p in ["battery status", "battery percentage", "how much battery", "check battery"]):
            resp = system_control.get_battery_report()
            return True, resp, "system_battery"

        if any(p in cmd for p in ["cpu usage", "ram usage", "system report", "system status", "hardware status"]):
            resp = system_control.get_hardware_report()
            return True, resp, "system_hardware"

        # 2. Volume & Hardware Controls
        if any(p in cmd for p in ["volume up", "increase volume", "raise volume", "sound up"]):
            success, resp = system_control.change_volume("up", steps=5)
            return True, "Increasing system volume.", "system_volume"

        if any(p in cmd for p in ["volume down", "decrease volume", "lower volume", "sound down"]):
            success, resp = system_control.change_volume("down", steps=5)
            return True, "Decreasing system volume.", "system_volume"

        if any(p in cmd for p in ["mute volume", "mute sound", "mute system", "unmute volume"]):
            success, resp = system_control.mute_volume()
            return True, "Toggling system volume mute.", "system_volume"

        if any(p in cmd for p in ["lock windows", "lock screen", "lock laptop", "lock computer", "lock pc"]):
            success, resp = system_control.lock_workstation()
            return True, resp, "system_lock"

        # 3. Application Launcher
        open_match = re.match(r"^(?:open|launch|start|run)\s+([a-zA-Z0-9_\-\s]+)$", cmd)
        if open_match:
            target_app = open_match.group(1).strip()
            # If target is web-based (e.g. open youtube, open github)
            if target_app in ["youtube", "google", "github", "chatgpt", "reddit", "gmail"]:
                success, resp = browser.open_site(target_app)
                return True, resp, "browser_open"
            
            success, resp = app_launcher.open_application(target_app)
            return True, resp, "app_launch"

        # 4. Application Closing
        close_match = re.match(r"^(?:close|exit|terminate|kill)\s+([a-zA-Z0-9_\-\s]+)$", cmd)
        if close_match:
            target_app = close_match.group(1).strip()
            success, resp = app_launcher.close_application(target_app)
            return True, resp, "app_close"

        # 5. Web Search & Navigation
        yt_search = re.match(r"^(?:search\s+youtube\s+for|search\s+on\s+youtube\s+for|youtube)\s+(.+)$", cmd)
        if yt_search:
            query = yt_search.group(1).strip()
            success, resp = browser.search_youtube(query)
            return True, resp, "web_search_youtube"

        web_search = re.match(r"^(?:search\s+(?:the\s+)?web\s+for|search\s+google\s+for|search\s+for|google)\s+(.+)$", cmd)
        if web_search:
            query = web_search.group(1).strip()
            success, resp = browser.search_google(query)
            return True, resp, "web_search_google"

        # 6. File Operations
        create_folder = re.match(r"^(?:create|make)\s+(?:a\s+)?folder\s+(?:named\s+)?([a-zA-Z0-9_\-]+)$", cmd)
        if create_folder:
            name = create_folder.group(1).strip()
            success, resp = file_manager.create_folder(name)
            return True, resp, "file_create_folder"

        create_file = re.match(r"^(?:create|make)\s+(?:a\s+)?(?:text\s+)?file\s+(?:named\s+)?([a-zA-Z0-9_\-\.]+)$", cmd)
        if create_file:
            name = create_file.group(1).strip()
            success, resp = file_manager.create_text_file(name)
            return True, resp, "file_create_file"

        if any(p in cmd for p in ["list files", "show files", "list directory", "what files are here"]):
            success, resp = file_manager.list_directory()
            return True, resp, "file_list"

        read_file = re.match(r"^(?:read|open)\s+(?:the\s+)?file\s+([a-zA-Z0-9_\-\.]+)$", cmd)
        if read_file:
            name = read_file.group(1).strip()
            success, resp = file_manager.read_text_file(name)
            return True, resp, "file_read"

        # Not an allowlisted automation command -> Forward to AI engine
        return False, None, None

# Global instance
command_router = CommandRouter()

