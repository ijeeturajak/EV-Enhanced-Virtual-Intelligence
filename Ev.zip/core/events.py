"""
EV - Enhanced Virtual Intelligence
Thread-Safe Qt Event Bus & Signals
"""

from PySide6.QtCore import QObject, Signal

class EVEventBus(QObject):
    # Assistant State Signals
    state_changed = Signal(str)          # 'IDLE', 'LISTENING', 'THINKING', 'SPEAKING', 'MUTED'
    wake_word_detected = Signal()       # Triggered when 'Hey EV' is recognized
    
    # Message & Chat Signals
    message_received = Signal(str, str) # role ('user' | 'ev'), text content
    
    # Telemetry & Hardware Signals
    telemetry_updated = Signal(dict)    # CPU, RAM, Battery, Network
    
    # Notification & Error Signals
    error_occurred = Signal(str)        # Error message to display in HUD

# Global singleton event bus
event_bus = EVEventBus()

