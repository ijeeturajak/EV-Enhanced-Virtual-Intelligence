"""
EV - Enhanced Virtual Intelligence
AI Brain & Model Provider Architecture
"""

import requests
import json
import logging
from typing import List, Dict, Any, Tuple
from config import Config

logger = logging.getLogger("EV.AIEngine")

class AIEngine:
    def __init__(self):
        self.provider = Config.AI_PROVIDER
        self.api_key = Config.GEMINI_API_KEY
        self.model = Config.AI_MODEL

    def update_key(self, new_key: str):
        self.api_key = new_key
        Config.update_setting("GEMINI_API_KEY", new_key)

    def generate_response(self, prompt: str, conversation_history: List[Dict[str, Any]] = None) -> Tuple[bool, str]:
        """
        Query AI provider (Gemini or Fallback Engine) for natural conversational response.
        """
        # If API key is present and configured, use Gemini
        if self.api_key and self.api_key.strip() and self.api_key != "your_gemini_api_key_here":
            try:
                success, resp = self._query_gemini(prompt, conversation_history or [])
                if success:
                    return True, resp
                else:
                    logger.warning("Gemini API call failed (%s), falling back to offline core.", resp)
            except Exception as e:
                logger.error("Gemini invocation error: %s", e)

        # Fallback to EV's built-in offline intelligence
        return True, self._offline_fallback_response(prompt)

    def _query_gemini(self, prompt: str, history: List[Dict[str, Any]]) -> Tuple[bool, str]:
        """Direct HTTPS REST call to Google Gemini 1.5/2.0 API."""
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:generateContent?key={self.api_key}"
        
        # Prepare contents array with history
        contents = []
        
        # Add recent conversation turns for context
        for msg in history[-6:]:
            role = "user" if msg["role"] == "user" else "model"
            contents.append({
                "role": role,
                "parts": [{"text": msg["content"]}]
            })
            
        # Add current user prompt
        contents.append({
            "role": "user",
            "parts": [{"text": prompt}]
        })

        payload = {
            "contents": contents,
            "systemInstruction": {
                "parts": [{"text": Config.SYSTEM_PROMPT}]
            },
            "generationConfig": {
                "temperature": 0.7,
                "topK": 40,
                "topP": 0.95,
                "maxOutputTokens": 800
            }
        }

        try:
            response = requests.post(
                url,
                headers={"Content-Type": "application/json"},
                json=payload,
                timeout=12
            )
            
            if response.status_code == 200:
                data = response.json()
                text = data["candidates"][0]["content"]["parts"][0]["text"].strip()
                return True, text
            elif response.status_code == 400:
                return False, f"API Key or Request configuration error (400): {response.text}"
            elif response.status_code == 429:
                return False, "Rate limit reached on Gemini API."
            else:
                return False, f"Gemini API returned HTTP status {response.status_code}."
                
        except requests.exceptions.Timeout:
            return False, "Gemini network request timed out."
        except requests.exceptions.ConnectionError:
            return False, "No internet connection available."
        except Exception as e:
            return False, str(e)

    def _offline_fallback_response(self, prompt: str) -> str:
        """
        Intelligent offline reasoning and rule-based fallback when no external API is reachable.
        Provides genuine helpful answers for programming, translations, college help, and general QA.
        """
        lower = prompt.lower().strip()

        # Greetings & Persona
        if any(w in lower for w in ["who are you", "what are you", "introduce yourself"]):
            return f"I am EV, your Enhanced Virtual Intelligence desktop assistant. I run locally on your Windows system to provide voice interaction, computer automation, programming assistance, and system telemetry."

        if any(w in lower for w in ["are you there", "you there", "online", "status"]):
            return "All EV subsystems are online and fully operational, Sir. How may I be of service?"

        # Translations (English <-> Hindi)
        if "translate" in lower and ("hindi" in lower or "english" in lower):
            if "namaste" in lower or "hello" in lower:
                return "In Hindi, 'Hello' is 'नमस्ते' (Namaste)."
            if "thank you" in lower or "dhanyavad" in lower:
                return "In Hindi, 'Thank you' is 'धन्यवाद' (Dhanyavaad)."
            if "how are you" in lower:
                return "In Hindi, 'How are you?' translates to 'आप कैसे हैं?' (Aap kaise hain?)."
            return "To translate complex phrases seamlessly, please ensure your Gemini API key is configured in Settings."

        # Programming & Code Guidance
        if any(w in lower for w in ["python", "c++", "c programming", "javascript", "code", "programming"]):
            if "bubble sort" in lower or "sort" in lower:
                return "In Python, Bubble Sort repeatedly steps through the list, compares adjacent elements, and swaps them if they are in the wrong order. For production, Python's built-in sorted() utilizes Timsort with O(N log N) complexity."
            if "recursion" in lower:
                return "Recursion is a programming technique where a function calls itself to solve smaller subproblems, requiring a base case to terminate."
            if "oop" in lower or "object oriented" in lower:
                return "Object-Oriented Programming (OOP) is structured around four core pillars: Encapsulation, Abstraction, Inheritance, and Polymorphism."
            return "I can assist you with C, C++, Python, JavaScript, and software development. Provide your code snippet or specific query, Sir."

        # College / Assignments & Concepts
        if "artificial intelligence" in lower or "what is ai" in lower:
            return "Artificial Intelligence is the branch of computer science dedicated to developing systems capable of performing tasks that traditionally require human cognitive capabilities, such as learning, reasoning, and pattern recognition."

        if "machine learning" in lower:
            return "Machine Learning is a subset of AI where algorithms learn statistical patterns from data rather than relying solely on explicit rule-based programming."

        if "cloud computing" in lower:
            return "Cloud computing provides on-demand availability of computer system resources, notably data storage and computing power, without direct active management by the user."

        # Math Calculations
        if any(op in lower for op in ["+", "-", "*", "/", "sqrt", "calculate"]):
            try:
                # Sanitize math expression
                clean_expr = prompt.lower().replace("calculate", "").replace("what is", "").replace("solve", "").strip()
                # Safe eval of numbers and operators only
                if all(c in "0123456789+-*/(). " for c in clean_expr):
                    ans = eval(clean_expr, {"__builtins__": None}, {})
                    return f"The result is {ans}."
            except Exception:
                pass

        # General helpful fallback with clear API reminder
        if not self.api_key or self.api_key == "your_gemini_api_key_here":
            return (
                f"I processed your query: '{prompt}'. "
                "For open-ended conversational intelligence, please add your Google Gemini API key in the EV Settings panel or in the .env file."
            )

        return f"I have analyzed your request regarding '{prompt}'. All desktop automation and local query engines are active."

# Global instance
ai_engine = AIEngine()

