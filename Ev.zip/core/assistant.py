"""
EV - Enhanced Virtual Intelligence
Central Assistant Brain & Orchestrator
"""

import threading
import logging
from typing import Optional
from config import Config
from database.database import db
from voice.text_to_speech import tts
from voice.listener import listener
from core.command_router import command_router
from core.ai_engine import ai_engine
from core.events import event_bus

logger = logging.getLogger("EV.Assistant")

class EVAssistant:
    def __init__(self):
        self.is_processing = False
        self._setup_voice_callbacks()

    def _setup_voice_callbacks(self):
        """Wire up voice listener and TTS callbacks."""
        listener.on_state_change = self._handle_listener_state
        listener.on_wake_detected = self._handle_wake_detected
        listener.on_command = self.process_command_async
        listener.on_error = lambda msg: event_bus.error_occurred.emit(msg)

        tts.set_callbacks(
            on_start=lambda: event_bus.state_changed.emit(listener.STATE_SPEAKING),
            on_finish=lambda: event_bus.state_changed.emit(listener.STATE_IDLE)
        )

    def _handle_listener_state(self, new_state: str):
        event_bus.state_changed.emit(new_state)

    def _handle_wake_detected(self):
        event_bus.wake_word_detected.emit()

    def start(self):
        """Boot up assistant services."""
        logger.info("Booting EV Assistant Core...")
        listener.start()
        
        # Initial greeting
        greeting = f"Good evening, {Config.USER_NAME}. EV is online and ready to assist you."
        self._record_message("ev", greeting)
        tts.speak(greeting)

    def process_command_async(self, text: str):
        """Launch command processing on a dedicated worker thread."""
        threading.Thread(target=self._process_command_worker, args=(text,), daemon=True).start()

    def _process_command_worker(self, text: str):
        if not text or not text.strip():
            event_bus.state_changed.emit(listener.STATE_IDLE)
            return

        clean_text = text.strip()
        logger.info("Processing command: '%s'", clean_text)
        
        # Record user message in UI and DB
        self._record_message("user", clean_text)
        event_bus.state_changed.emit(listener.STATE_THINKING)

        try:
            # 1. Check Allowlisted Command Router for Windows automation
            handled, voice_resp, action_type = command_router.route_command(clean_text)

            if handled and voice_resp:
                # Log successful automation action
                db.log_command(clean_text, action_type or "system", "success", voice_resp)
                self._record_message("ev", voice_resp)
                tts.speak(voice_resp)
                return

            # 2. General Knowledge / Coding / Conversation -> Forward to AI Brain
            history = db.get_recent_conversation(limit=8)
            success, ai_resp = ai_engine.generate_response(clean_text, history)
            
            self._record_message("ev", ai_resp)
            tts.speak(ai_resp)

        except Exception as e:
            logger.error("Error processing command '%s': %s", clean_text, e)
            err_msg = "I encountered an internal operational issue processing your request."
            self._record_message("ev", err_msg)
            tts.speak(err_msg)
        finally:
            if not tts.is_speaking:
                event_bus.state_changed.emit(listener.STATE_IDLE)

    def _record_message(self, role: str, content: str):
        db.add_message(role, content)
        event_bus.message_received.emit(role, content)

    def stop_speaking(self):
        """Interrupt any active speech output."""
        tts.stop()
        event_bus.state_changed.emit(listener.STATE_IDLE)

    def toggle_mic(self) -> bool:
        """Toggle microphone mute."""
        is_muted = listener.toggle_mute()
        return is_muted

# Global assistant singleton
assistant = EVAssistant()

