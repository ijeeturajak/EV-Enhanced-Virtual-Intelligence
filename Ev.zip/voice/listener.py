"""
EV - Enhanced Virtual Intelligence
Continuous Background Voice Listener & State Machine
"""

import threading
import time
import logging
from typing import Optional, Callable
from voice.speech_to_text import stt
from voice.wake_word import wake_detector
from voice.text_to_speech import tts
from config import Config

logger = logging.getLogger("EV.Listener")

class VoiceListener:
    STATE_IDLE = "IDLE"
    STATE_LISTENING = "LISTENING"
    STATE_THINKING = "THINKING"
    STATE_SPEAKING = "SPEAKING"
    STATE_MUTED = "MUTED"

    def __init__(self):
        self.state = self.STATE_IDLE
        self.is_running = False
        self.is_muted = False
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()

        # Callbacks
        self.on_state_change: Optional[Callable[[str], None]] = None
        self.on_wake_detected: Optional[Callable[[], None]] = None
        self.on_command: Optional[Callable[[str], None]] = None
        self.on_error: Optional[Callable[[str], None]] = None

    def set_state(self, new_state: str):
        if self.state != new_state:
            self.state = new_state
            logger.debug("Listener state changed to: %s", new_state)
            if self.on_state_change:
                try:
                    self.on_state_change(new_state)
                except Exception as e:
                    logger.error("Error in on_state_change callback: %s", e)

    def start(self):
        """Start background continuous listening thread."""
        if self.is_running:
            return
        self.is_running = True
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._listen_loop, daemon=True)
        self._thread.start()
        logger.info("Continuous Voice Listener started.")

    def stop(self):
        """Stop listening thread."""
        self.is_running = False
        self._stop_event.set()

    def toggle_mute(self) -> bool:
        """Toggle microphone mute."""
        self.is_muted = not self.is_muted
        if self.is_muted:
            self.set_state(self.STATE_MUTED)
        else:
            self.set_state(self.STATE_IDLE)
        return self.is_muted

    def trigger_manual_listen(self):
        """Force manual listen (when user clicks mic button in UI)."""
        if self.is_muted:
            self.is_muted = False
        
        # Run one-shot listen in a worker thread so UI doesn't hang
        threading.Thread(target=self._one_shot_listen, daemon=True).start()

    def _one_shot_listen(self):
        # Stop speaking if currently speaking
        if tts.is_speaking:
            tts.stop()
            time.sleep(0.2)

        self.set_state(self.STATE_LISTENING)
        success, text = stt.listen_and_transcribe(timeout=6.0, phrase_time_limit=14.0)

        if success and text:
            # Check if it contains wake word or is a direct command
            detected, remaining = wake_detector.check(text)
            cmd = remaining if (detected and remaining) else text
            
            self.set_state(self.STATE_THINKING)
            if self.on_command:
                self.on_command(cmd)
        else:
            self.set_state(self.STATE_IDLE)
            if "Timeout" not in text and self.on_error:
                self.on_error(text)

    def _listen_loop(self):
        """Continuous ambient wake-word listening loop."""
        stt.calibrate_noise(duration=1.0)

        while not self._stop_event.is_set():
            # If muted or EV is speaking, pause to avoid hearing own voice (echo-loop prevention)
            if self.is_muted or tts.is_speaking:
                time.sleep(0.3)
                continue

            if not Config.CONTINUOUS_LISTENING:
                time.sleep(0.5)
                continue

            try:
                # Listen in short ambient chunks for wake-word
                self.set_state(self.STATE_IDLE)
                success, phrase = stt.listen_and_transcribe(timeout=2.0, phrase_time_limit=5.0)

                if not success or not phrase:
                    continue

                # Echo prevention check
                if tts.is_speaking:
                    continue

                detected, remaining_cmd = wake_detector.check(phrase)

                if detected:
                    logger.info("Wake word detected! Phrase: '%s'", phrase)
                    self.set_state(self.STATE_LISTENING)

                    if self.on_wake_detected:
                        self.on_wake_detected()

                    # If command was spoken in the same breath (e.g. "Hey EV open chrome")
                    if remaining_cmd and len(remaining_cmd) > 2:
                        self.set_state(self.STATE_THINKING)
                        if self.on_command:
                            self.on_command(remaining_cmd)
                    else:
                        # User just said "Hey EV" -> prompt and listen for active command
                        tts.speak("Yes, Sir? I'm listening.")
                        time.sleep(1.0)
                        
                        self.set_state(self.STATE_LISTENING)
                        success_cmd, active_cmd = stt.listen_and_transcribe(timeout=5.0, phrase_time_limit=12.0)
                        
                        if success_cmd and active_cmd:
                            self.set_state(self.STATE_THINKING)
                            if self.on_command:
                                self.on_command(active_cmd)
                        else:
                            self.set_state(self.STATE_IDLE)

            except Exception as e:
                logger.error("Exception in listener loop: %s", e)
                time.sleep(0.5)

# Global instance
listener = VoiceListener()

