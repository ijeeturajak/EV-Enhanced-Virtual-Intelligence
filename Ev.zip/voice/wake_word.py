"""
EV - Enhanced Virtual Intelligence
Wake-Word Detection & Phrase Extraction
"""

import re
from typing import Tuple, Optional
from config import Config

class WakeWordDetector:
    def __init__(self):
        self.primary_wake = Config.WAKE_WORD.lower()
        
        # Phonetic & common speech-to-text variations for "Hey EV" / "EV"
        self.patterns = [
            r"\bhey\s+ev\b",
            r"\bhey\s+eve\b",
            r"\bhey\s+ivy\b",
            r"\bhey\s+e\s*v\b",
            r"\bhi\s+ev\b",
            r"\bhello\s+ev\b",
            r"\bok\s+ev\b",
            r"\bokay\s+ev\b",
            r"\bheavy\b",  # Common STT misinterpretation of "Hey EV"
            r"\bhey\s+jarvis\b",
            r"\bjarvis\b",
            r"\bev\b"
        ]
        self._compiled_regex = re.compile("|".join(self.patterns), re.IGNORECASE)

    def check(self, text: str) -> Tuple[bool, Optional[str]]:
        """
        Check if the text contains a wake word.
        Returns:
            (detected: bool, remaining_command: str)
        """
        if not text:
            return False, None

        clean_text = text.strip()
        match = self._compiled_regex.search(clean_text)
        
        if match:
            # Extract everything after the wake word
            end_idx = match.end()
            remaining = clean_text[end_idx:].strip()
            # Clean leading punctuation like comma, period, colon
            remaining = re.sub(r"^[,\.\:\;\-\s]+", "", remaining).strip()
            return True, remaining
        
        # Also check exact wake word or starts with
        if clean_text.lower().startswith(self.primary_wake):
            remaining = clean_text[len(self.primary_wake):].strip()
            remaining = re.sub(r"^[,\.\:\;\-\s]+", "", remaining).strip()
            return True, remaining

        return False, None

# Global detector instance
wake_detector = WakeWordDetector()

