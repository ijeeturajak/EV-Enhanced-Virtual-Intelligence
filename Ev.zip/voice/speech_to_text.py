"""
EV - Enhanced Virtual Intelligence
Speech-to-Text (STT) Recognition Engine
"""

import logging
from typing import Optional, Tuple
import speech_recognition as sr
from config import Config

logger = logging.getLogger("EV.STT")

class SpeechToText:
    def __init__(self):
        self.recognizer = sr.Recognizer()
        self.recognizer.energy_threshold = Config.ENERGY_THRESHOLD
        self.recognizer.dynamic_energy_threshold = True
        self.recognizer.pause_threshold = Config.SILENCE_THRESHOLD
        self.recognizer.non_speaking_duration = 0.5
        
        self.microphone: Optional[sr.Microphone] = None
        self._init_microphone()

    def _init_microphone(self) -> bool:
        """Attempt to find and initialize default system microphone."""
        try:
            mic_list = sr.Microphone.list_microphone_names()
            if not mic_list:
                logger.warning("No microphone detected on the system.")
                self.microphone = None
                return False
            self.microphone = sr.Microphone()
            return True
        except Exception as e:
            logger.error("Failed to initialize microphone: %s", e)
            self.microphone = None
            return False

    def calibrate_noise(self, duration: float = 1.0):
        """Calibrate for ambient room noise."""
        if not self.microphone:
            if not self._init_microphone():
                return
        try:
            with self.microphone as source:
                self.recognizer.adjust_for_ambient_noise(source, duration=duration)
                logger.info("Ambient noise calibrated. Energy threshold: %s", self.recognizer.energy_threshold)
        except Exception as e:
            logger.warning("Noise calibration warning: %s", e)

    def listen_and_transcribe(self, timeout: Optional[float] = 6.0, phrase_time_limit: Optional[float] = 12.0) -> Tuple[bool, str]:
        """
        Listen to audio and transcribe via Speech Recognition.
        Returns: (success: bool, transcribed_text: str)
        """
        if not self.microphone:
            if not self._init_microphone():
                return False, "Microphone not available"

        try:
            with self.microphone as source:
                audio = self.recognizer.listen(source, timeout=timeout, phrase_time_limit=phrase_time_limit)
                
            # Determine recognition language (English US only)
            lang_code = Config.LANGUAGE if "en" in Config.LANGUAGE.lower() else "en-US"
            
            # Use Google Speech Recognition API (built into speech_recognition)
            text = self.recognizer.recognize_google(audio, language=lang_code)
            return True, text.strip()

        except sr.WaitTimeoutError:
            return False, "Timeout: No speech detected"
        except sr.UnknownValueError:
            return False, "Speech was unintelligible"
        except sr.RequestError as e:
            return False, f"Speech recognition service error: {e}"
        except Exception as e:
            logger.error("Transcription error: %s", e)
            return False, f"Audio error: {e}"

# Global instance
stt = SpeechToText()

