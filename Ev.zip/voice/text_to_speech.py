"""
EV - Enhanced Virtual Intelligence
Text-To-Speech (TTS) Voice Engine
Primary: Microsoft Jenny Neural (en-US-JennyNeural via Azure Cognitive Services)
Fallback: Windows Native SAPI5 (pyttsx3)
"""

import threading
import queue
import re
import logging
import xml.sax.saxutils as saxutils
from typing import Optional, Callable
import pyttsx3
from config import Config

logger = logging.getLogger("EV.TTS")

# Safe import of Azure Cognitive Services Speech SDK
try:
    import azure.cognitiveservices.speech as speechsdk
    AZURE_SDK_AVAILABLE = True
except ImportError:
    speechsdk = None
    AZURE_SDK_AVAILABLE = False
    logger.info("Azure Speech SDK not installed; using local Windows SAPI5 voice engine.")

class TextToSpeech:
    def __init__(self):
        self._speech_queue = queue.Queue()
        self._stop_event = threading.Event()
        self._is_speaking = False
        self._on_start_cb: Optional[Callable] = None
        self._on_finish_cb: Optional[Callable] = None
        
        self._azure_synthesizer = None
        self._pyttsx3_engine = None
        
        # Start background worker thread
        self._worker_thread = threading.Thread(target=self._speech_loop, daemon=True)
        self._worker_thread.start()

    def set_callbacks(self, on_start: Optional[Callable] = None, on_finish: Optional[Callable] = None):
        self._on_start_cb = on_start
        self._on_finish_cb = on_finish

    @property
    def is_speaking(self) -> bool:
        return self._is_speaking

    def _clean_text_for_speech(self, text: str) -> str:
        """Strip markdown, URLs, and code blocks for clean, natural speech."""
        if not text:
            return ""
        
        # Replace code blocks with a short spoken summary
        text = re.sub(r'```[\s\S]*?```', ' Code block provided on screen. ', text)
        text = re.sub(r'`([^`]+)`', r'\1', text)
        
        # Remove markdown bold/italics
        text = re.sub(r'\*\*([^*]+)\*\*', r'\1', text)
        text = re.sub(r'\*([^*]+)\*', r'\1', text)
        text = re.sub(r'#+\s*', '', text)
        
        # Strip URLs
        text = re.sub(r'https?://\S+', 'link', text)
        
        # Clean multiple spaces/newlines
        text = re.sub(r'\s+', ' ', text).strip()
        return text

    def speak(self, text: str, interrupt_current: bool = False):
        """Queue text to be spoken."""
        cleaned = self._clean_text_for_speech(text)
        if not cleaned:
            return

        if interrupt_current:
            self.stop()

        self._speech_queue.put(cleaned)

    def stop(self):
        """Immediately interrupt and stop speaking."""
        self._stop_event.set()
        
        # Clear any pending queued phrases
        while not self._speech_queue.empty():
            try:
                self._speech_queue.get_nowait()
            except queue.Empty:
                break

        # Stop active Azure synthesizer if running
        if self._azure_synthesizer:
            try:
                self._azure_synthesizer.stop_speaking_async()
            except Exception:
                pass

        # Stop pyttsx3 engine if running
        if self._pyttsx3_engine:
            try:
                self._pyttsx3_engine.stop()
            except Exception:
                pass

        self._is_speaking = False
        if self._on_finish_cb:
            try:
                self._on_finish_cb()
            except Exception:
                pass

    def _init_azure(self) -> bool:
        """Initialize Azure SpeechSynthesizer if credentials exist."""
        if not AZURE_SDK_AVAILABLE:
            return False

        key = Config.AZURE_SPEECH_KEY.strip()
        region = Config.AZURE_SPEECH_REGION.strip()

        if not key or not region:
            logger.debug("Azure Speech credentials not provided. Using Windows SAPI5 voice engine.")
            self._azure_synthesizer = None
            return False

        try:
            speech_config = speechsdk.SpeechConfig(subscription=key, region=region)
            speech_config.speech_synthesis_voice_name = Config.VOICE_NAME or "en-US-JennyNeural"
            
            # Use default system audio speaker
            audio_config = speechsdk.audio.AudioOutputConfig(use_default_speaker=True)
            self._azure_synthesizer = speechsdk.SpeechSynthesizer(
                speech_config=speech_config,
                audio_config=audio_config
            )
            logger.info("Microsoft Jenny Neural initialized via Azure Speech (Voice: %s, Region: %s).",
                        speech_config.speech_synthesis_voice_name, region)
            return True
        except Exception as e:
            logger.warning("Failed to initialize Azure Speech Synthesizer: %s. Using fallback.", e)
            self._azure_synthesizer = None
            return False

    def _init_pyttsx3(self):
        """Initialize local Windows SAPI5 engine as reliable fallback."""
        try:
            import pythoncom
            pythoncom.CoInitialize()
        except Exception:
            pass

        try:
            engine = pyttsx3.init()
            engine.setProperty('rate', Config.VOICE_RATE)
            engine.setProperty('volume', Config.VOICE_VOLUME)
            
            # Select best local natural female voice matching Jenny or Zira
            voices = engine.getProperty('voices')
            selected_voice = None
            
            # 1. Prefer local Jenny if installed
            for v in voices:
                if 'jenny' in v.name.lower():
                    selected_voice = v.id
                    break
            
            # 2. Prefer Zira or any female voice
            if not selected_voice and Config.VOICE_GENDER == 'female':
                for v in voices:
                    if 'zira' in v.name.lower() or 'female' in v.name.lower():
                        selected_voice = v.id
                        break
            
            # 3. Fallback to first available voice
            if selected_voice:
                engine.setProperty('voice', selected_voice)
            elif voices:
                engine.setProperty('voice', voices[0].id)
                
            self._pyttsx3_engine = engine
        except Exception as e:
            logger.error("Failed to initialize pyttsx3 fallback engine: %s", e)
            self._pyttsx3_engine = None

    def _build_jenny_ssml(self, text: str) -> str:
        """Build SSML for Microsoft Jenny Neural with moderate speed and comfortable volume."""
        escaped_text = saxutils.escape(text, {'"': '&quot;', "'": '&apos;'})
        
        # Calculate prosody rate offset from baseline 175 WPM
        rate_diff = int(((Config.VOICE_RATE - 175) / 175) * 100)
        rate_str = f"{rate_diff:+d}%" if rate_diff != 0 else "0%"
        
        # Volume percentage (0% to 100%)
        vol_pct = max(0, min(100, int(Config.VOICE_VOLUME * 100)))
        vol_str = f"{vol_pct}%"

        voice_name = Config.VOICE_NAME or "en-US-JennyNeural"

        return f"""<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="en-US">
    <voice name="{voice_name}">
        <prosody rate="{rate_str}" volume="{vol_str}">
            {escaped_text}
        </prosody>
    </voice>
</speak>"""

    def _speak_with_azure(self, text: str) -> bool:
        """Attempt speech synthesis using Azure Microsoft Jenny Neural."""
        if not self._azure_synthesizer:
            if not self._init_azure():
                return False

        try:
            ssml = self._build_jenny_ssml(text)
            result = self._azure_synthesizer.speak_ssml_async(ssml).get()
            
            if result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
                return True
            elif result.reason == speechsdk.ResultReason.Canceled:
                cancellation = speechsdk.SpeechSynthesisCancellationDetails(result)
                logger.warning("Azure Speech synthesis canceled: %s (%s). Falling back to Windows voice.",
                               cancellation.reason, cancellation.error_details)
                return False
        except Exception as e:
            logger.warning("Azure Speech execution error: %s. Falling back to Windows voice.", e)
            return False
            
        return False

    def _speak_with_pyttsx3(self, text: str):
        """Speak using local Windows SAPI5 voice engine."""
        if not self._pyttsx3_engine:
            self._init_pyttsx3()

        if not self._pyttsx3_engine:
            logger.error("No TTS engine available to speak phrase.")
            return

        try:
            self._pyttsx3_engine.setProperty('rate', Config.VOICE_RATE)
            self._pyttsx3_engine.setProperty('volume', Config.VOICE_VOLUME)
            self._pyttsx3_engine.say(text)
            self._pyttsx3_engine.runAndWait()
        except Exception as e:
            logger.error("pyttsx3 speech error: %s", e)

    def _speech_loop(self):
        """Dedicated background worker loop processing queued speech sequentially."""
        try:
            import pythoncom
            pythoncom.CoInitialize()
        except Exception:
            pass

        # Pre-initialize engines
        self._init_azure()
        self._init_pyttsx3()

        while True:
            try:
                text = self._speech_queue.get()
                if not text:
                    continue

                self._stop_event.clear()
                self._is_speaking = True

                if self._on_start_cb:
                    try:
                        self._on_start_cb()
                    except Exception:
                        pass

                # Primary: Attempt Microsoft Jenny Neural
                success = False
                if AZURE_SDK_AVAILABLE and Config.AZURE_SPEECH_KEY.strip() and Config.AZURE_SPEECH_REGION.strip():
                    success = self._speak_with_azure(text)

                # Fallback: Windows SAPI5 if Azure is unavailable or failed
                if not success and not self._stop_event.is_set():
                    self._speak_with_pyttsx3(text)

                self._is_speaking = False
                if self._on_finish_cb:
                    try:
                        self._on_finish_cb()
                    except Exception:
                        pass

            except Exception as e:
                logger.error("TTS loop error: %s", e)
                self._is_speaking = False
                if self._on_finish_cb:
                    try:
                        self._on_finish_cb()
                    except Exception:
                        pass

    def get_available_voices(self):
        """Return list of available voice identifiers."""
        voices = [
            {"id": "en-US-JennyNeural", "name": "Microsoft Jenny Neural (en-US, Azure)"}
        ]
        
        try:
            import pythoncom
            pythoncom.CoInitialize()
        except Exception:
            pass

        try:
            eng = pyttsx3.init()
            for v in eng.getProperty('voices'):
                voices.append({"id": v.id, "name": f"{v.name} (Windows SAPI5)"})
        except Exception:
            pass

        return voices

# Global TTS instance
tts = TextToSpeech()
