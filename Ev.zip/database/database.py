"""
EV - Enhanced Virtual Intelligence
Persistent SQLite Database & Memory Management
"""

import sqlite3
import json
import logging
from datetime import datetime
from typing import List, Dict, Any, Optional
from config import DATABASE_PATH

logger = logging.getLogger("EV.Database")

class EVDatabase:
    def __init__(self, db_path: Optional[str] = None):
        self.db_path = str(db_path or DATABASE_PATH)
        self._init_db()

    def _get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        """Create necessary schema tables if they do not exist."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            # Conversation History
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS conversations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    role TEXT NOT NULL,
                    content TEXT NOT NULL,
                    language TEXT DEFAULT 'en'
                )
            """)

            # Persistent Memories (User preferences, facts, project context)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS memories (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    key TEXT UNIQUE NOT NULL,
                    value TEXT NOT NULL,
                    category TEXT DEFAULT 'general',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
            """)

            # Command Audit History
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS command_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    raw_command TEXT NOT NULL,
                    action_type TEXT NOT NULL,
                    status TEXT NOT NULL,
                    execution_details TEXT
                )
            """)

            # Key-Value Settings
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
            """)
            
            conn.commit()
            logger.info("Database initialized successfully at %s", self.db_path)

    # --- Conversation Methods ---

    def add_message(self, role: str, content: str, language: str = 'en') -> int:
        """Store a user or EV response in conversation memory."""
        now = datetime.now().isoformat()
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO conversations (timestamp, role, content, language) VALUES (?, ?, ?, ?)",
                (now, role, content, language)
            )
            conn.commit()
            return cursor.lastrowid

    def get_recent_conversation(self, limit: int = 20) -> List[Dict[str, Any]]:
        """Retrieve the last N messages for chat history and AI context."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT id, timestamp, role, content, language FROM conversations ORDER BY id DESC LIMIT ?",
                (limit,)
            )
            rows = cursor.fetchall()
            return [dict(r) for r in reversed(rows)]

    def clear_conversation_history(self):
        """Clear all chat history."""
        with self._get_connection() as conn:
            conn.execute("DELETE FROM conversations")
            conn.commit()

    # --- Memory System Methods ---

    def set_memory(self, key: str, value: str, category: str = "general"):
        """Store or update user preference / memory item."""
        now = datetime.now().isoformat()
        with self._get_connection() as conn:
            conn.execute("""
                INSERT INTO memories (key, value, category, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(key) DO UPDATE SET
                    value = excluded.value,
                    category = excluded.category,
                    updated_at = excluded.updated_at
            """, (key, value, category, now, now))
            conn.commit()

    def get_memory(self, key: str) -> Optional[str]:
        """Fetch a specific memory value."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT value FROM memories WHERE key = ?", (key,))
            row = cursor.fetchone()
            return row["value"] if row else None

    def get_all_memories(self) -> List[Dict[str, Any]]:
        """Retrieve all stored user memories."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id, key, value, category, updated_at FROM memories ORDER BY key ASC")
            return [dict(r) for r in cursor.fetchall()]

    def delete_memory(self, key: str) -> bool:
        """Remove a memory entry."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM memories WHERE key = ?", (key,))
            conn.commit()
            return cursor.rowcount > 0

    # --- Command Audit Methods ---

    def log_command(self, raw_command: str, action_type: str, status: str = "success", details: str = ""):
        """Log an executed automation command."""
        now = datetime.now().isoformat()
        with self._get_connection() as conn:
            conn.execute(
                "INSERT INTO command_history (timestamp, raw_command, action_type, status, execution_details) VALUES (?, ?, ?, ?, ?)",
                (now, raw_command, action_type, status, details)
            )
            conn.commit()

    def get_frequent_commands(self, limit: int = 5) -> List[Dict[str, Any]]:
        """Find most frequently executed actions."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT raw_command, action_type, COUNT(*) as count 
                FROM command_history 
                GROUP BY raw_command 
                ORDER BY count DESC 
                LIMIT ?
            """, (limit,))
            return [dict(r) for r in cursor.fetchall()]

    # --- Settings Persistence ---

    def set_setting(self, key: str, value: Any):
        """Persist a setting into the database."""
        now = datetime.now().isoformat()
        val_str = json.dumps(value) if not isinstance(value, str) else value
        with self._get_connection() as conn:
            conn.execute("""
                INSERT INTO settings (key, value, updated_at) VALUES (?, ?, ?)
                ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
            """, (key, val_str, now))
            conn.commit()

    def get_setting(self, key: str, default: Any = None) -> Any:
        """Retrieve setting from database."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT value FROM settings WHERE key = ?", (key,))
            row = cursor.fetchone()
            if not row:
                return default
            val = row["value"]
            try:
                return json.loads(val)
            except Exception:
                return val

# Global instance
db = EVDatabase()

