"""
EV - Enhanced Virtual Intelligence
Windows Application Launcher & Process Manager
"""

import os
import subprocess
import logging
from typing import Tuple, Optional
import psutil
from config import Config

logger = logging.getLogger("EV.AppLauncher")

class AppLauncher:
    def __init__(self):
        self.registry = Config.APP_REGISTRY

    def open_application(self, app_name: str) -> Tuple[bool, str]:
        """Launch a Windows application by name."""
        clean_name = app_name.lower().strip()
        
        # Check direct registry match or partial match
        target_cmds = None
        for key, cmds in self.registry.items():
            if key in clean_name or clean_name in key:
                target_cmds = cmds
                break

        if not target_cmds:
            # Fallback to direct Windows start command
            target_cmds = [clean_name]

        for cmd in target_cmds:
            try:
                # ms-settings protocol handler
                if cmd.startswith("ms-settings:"):
                    os.system(f"start {cmd}")
                    return True, f"Opening Windows Settings."
                
                # Standard Windows process spawn
                subprocess.Popen(
                    cmd,
                    shell=True,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL
                )
                return True, f"Launching {app_name}."
            except Exception as e:
                logger.warning("Failed launching '%s' with command '%s': %s", app_name, cmd, e)

        return False, f"Could not find or launch {app_name} on your system."

    def close_application(self, app_name: str) -> Tuple[bool, str]:
        """Close running application process."""
        clean_name = app_name.lower().strip()
        closed_count = 0

        # Mapping common names to Windows process executable names
        proc_map = {
            "chrome": "chrome.exe",
            "google chrome": "chrome.exe",
            "vscode": "Code.exe",
            "visual studio code": "Code.exe",
            "code": "Code.exe",
            "notepad": "notepad.exe",
            "calculator": "CalculatorApp.exe",
            "explorer": "explorer.exe",
            "spotify": "Spotify.exe",
            "terminal": "WindowsTerminal.exe"
        }

        target_proc = proc_map.get(clean_name, f"{clean_name}.exe")

        try:
            for proc in psutil.process_iter(['pid', 'name']):
                if proc.info['name'] and target_proc.lower() in proc.info['name'].lower():
                    proc.terminate()
                    closed_count += 1
            
            if closed_count > 0:
                return True, f"Closed {closed_count} instance(s) of {app_name}."
            return False, f"No active process found for {app_name}."
        except Exception as e:
            logger.error("Error closing process %s: %s", app_name, e)
            return False, f"Failed to close {app_name}: {e}"

# Global instance
app_launcher = AppLauncher()

