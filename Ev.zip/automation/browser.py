"""
EV - Enhanced Virtual Intelligence
Web Browser Automation & Search Operations
"""

import webbrowser
import urllib.parse
import logging
from typing import Tuple
from config import Config

logger = logging.getLogger("EV.Browser")

class BrowserController:
    def __init__(self):
        self.web_registry = Config.WEB_REGISTRY

    def open_site(self, site_name: str) -> Tuple[bool, str]:
        """Open a recognized site from the web registry."""
        key = site_name.lower().strip()
        url = self.web_registry.get(key)
        
        if not url:
            # Check if domain-like (e.g. twitter.com)
            if "." in key:
                url = f"https://{key}" if not key.startswith("http") else key
            else:
                return self.search_google(site_name)

        try:
            webbrowser.open(url)
            return True, f"Navigating to {site_name}."
        except Exception as e:
            logger.error("Error opening URL %s: %s", url, e)
            return False, f"Failed opening {site_name}: {e}"

    def search_google(self, query: str) -> Tuple[bool, str]:
        """Perform a web search on Google."""
        clean_query = query.strip()
        if not clean_query:
            return False, "Query was empty."

        encoded = urllib.parse.quote_plus(clean_query)
        search_url = f"https://www.google.com/search?q={encoded}"
        try:
            webbrowser.open(search_url)
            return True, f"Searching the web for: {clean_query}."
        except Exception as e:
            logger.error("Search failed: %s", e)
            return False, f"Could not perform web search: {e}"

    def search_youtube(self, query: str) -> Tuple[bool, str]:
        """Search videos on YouTube."""
        clean_query = query.strip()
        if not clean_query:
            return False, "Query was empty."

        encoded = urllib.parse.quote_plus(clean_query)
        yt_url = f"https://www.youtube.com/results?search_query={encoded}"
        try:
            webbrowser.open(yt_url)
            return True, f"Searching YouTube for: {clean_query}."
        except Exception as e:
            logger.error("YouTube search failed: %s", e)
            return False, f"Could not open YouTube search: {e}"

# Global instance
browser = BrowserController()

