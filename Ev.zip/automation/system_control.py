"""
EV - Enhanced Virtual Intelligence
Windows System Hardware Telemetry & Control Operations
"""

import datetime
import socket
import ctypes
import logging
from typing import Dict, Any, Tuple
import psutil

logger = logging.getLogger("EV.SystemControl")

class SystemControl:
    # Windows Virtual Key Codes for Media / Volume Control
    VK_VOLUME_MUTE = 0xAD
    VK_VOLUME_DOWN = 0xAE
    VK_VOLUME_UP = 0xAF

    @staticmethod
    def get_system_telemetry() -> Dict[str, Any]:
        """Fetch current hardware stats for HUD display and voice reports."""
        cpu = psutil.cpu_percent(interval=None)
        mem = psutil.virtual_memory()
        try:
            battery = psutil.sensors_battery()
        except Exception:
            battery = None
        
        battery_data = {
            "percent": battery.percent if battery else 100,
            "power_plugged": battery.power_plugged if battery else True,
            "has_battery": battery is not None
        }

        # Check internet reachability (fast socket connect to Cloudflare DNS 1.1.1.1:53)
        online = False
        try:
            s = socket.create_connection(("1.1.1.1", 53), timeout=0.8)
            s.close()
            online = True
        except Exception:
            online = False

        return {
            "cpu_percent": cpu,
            "ram_percent": mem.percent,
            "ram_used_gb": round(mem.used / (1024 ** 3), 2),
            "ram_total_gb": round(mem.total / (1024 ** 3), 2),
            "battery": battery_data,
            "online": online,
            "time_str": datetime.datetime.now().strftime("%I:%M:%S %p"),
            "date_str": datetime.datetime.now().strftime("%A, %B %d, %Y")
        }

    @staticmethod
    def get_time_report() -> str:
        """Formatted voice response for time queries."""
        now = datetime.datetime.now()
        return f"The current time is {now.strftime('%I:%M %p')} on {now.strftime('%A, %B %d')}."

    @staticmethod
    def get_battery_report() -> str:
        """Formatted voice response for battery query."""
        try:
            b = psutil.sensors_battery()
        except Exception:
            b = None
        if not b:
            return "This system is running on continuous AC power with no battery detected."
        state = "charging" if b.power_plugged else "discharging"
        return f"Battery is at {b.percent} percent and currently {state}."

    @staticmethod
    def get_hardware_report() -> str:
        """Formatted voice response for CPU and RAM load."""
        cpu = psutil.cpu_percent(interval=0.2)
        mem = psutil.virtual_memory()
        return f"CPU utilization is at {cpu} percent. Memory usage is {mem.percent} percent, with {round(mem.used / (1024**3), 1)} gigabytes utilized out of {round(mem.total / (1024**3), 1)}."

    @classmethod
    def change_volume(cls, direction: str, steps: int = 5) -> Tuple[bool, str]:
        """Adjust system master volume via Windows keybd_event."""
        vk_code = cls.VK_VOLUME_UP if direction == "up" else cls.VK_VOLUME_DOWN
        for _ in range(steps):
            ctypes.windll.user32.keybd_event(vk_code, 0, 0, 0)
            ctypes.windll.user32.keybd_event(vk_code, 0, 2, 0) # KEYEVENTF_KEYUP
        return True, f"Adjusted volume {direction}."

    @classmethod
    def mute_volume(cls) -> Tuple[bool, str]:
        """Toggle system volume mute."""
        ctypes.windll.user32.keybd_event(cls.VK_VOLUME_MUTE, 0, 0, 0)
        ctypes.windll.user32.keybd_event(cls.VK_VOLUME_MUTE, 0, 2, 0)
        return True, "Volume mute toggled."

    @staticmethod
    def lock_workstation() -> Tuple[bool, str]:
        """Lock the Windows desktop session."""
        try:
            ctypes.windll.user32.LockWorkStation()
            return True, "Locking workstation now."
        except Exception as e:
            logger.error("Failed to lock workstation: %s", e)
            return False, f"Could not lock workstation: {e}"

# Global instance
system_control = SystemControl()

