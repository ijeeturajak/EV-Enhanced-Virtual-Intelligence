"""
EV - Enhanced Virtual Intelligence
Secure File & Directory Management Operations
"""

import os
from pathlib import Path
import logging
from typing import Tuple, List

logger = logging.getLogger("EV.FileManager")

class FileManager:
    def __init__(self):
        # Default safe operational root is user's home or desktop
        self.home_dir = Path.home()
        self.desktop_dir = self.home_dir / "Desktop"
        self.documents_dir = self.home_dir / "Documents"

    def _resolve_safe_path(self, target: str) -> Path:
        """Resolve a relative or named path to a safe local directory."""
        p = Path(target)
        if p.is_absolute():
            return p
        # Default to Desktop if relative
        return self.desktop_dir / p

    def create_folder(self, folder_name: str, parent_dir: str = "") -> Tuple[bool, str]:
        """Create a new folder safely."""
        try:
            target_parent = Path(parent_dir) if parent_dir else self.desktop_dir
            new_path = target_parent / folder_name
            new_path.mkdir(parents=True, exist_ok=True)
            return True, f"Created directory at: {new_path}"
        except Exception as e:
            logger.error("Failed to create folder: %s", e)
            return False, f"Could not create folder: {e}"

    def create_text_file(self, filename: str, content: str = "", location: str = "") -> Tuple[bool, str]:
        """Create a text file with optional content."""
        try:
            target_parent = Path(location) if location else self.desktop_dir
            if not filename.endswith((".txt", ".md", ".py", ".json", ".csv", ".log")):
                filename += ".txt"
            
            file_path = target_parent / filename
            file_path.write_text(content, encoding="utf-8")
            return True, f"File created successfully: {file_path.name}"
        except Exception as e:
            logger.error("Failed to create file: %s", e)
            return False, f"Failed to create file: {e}"

    def read_text_file(self, file_path_str: str) -> Tuple[bool, str]:
        """Read and return content of a text file."""
        try:
            p = self._resolve_safe_path(file_path_str)
            if not p.exists() or not p.is_file():
                return False, f"File '{file_path_str}' does not exist."
            
            if p.stat().st_size > 500_000:
                return False, "File is too large to read via voice."

            content = p.read_text(encoding="utf-8", errors="replace")
            # Truncate if too long for voice output
            preview = content[:500] + ("..." if len(content) > 500 else "")
            return True, preview
        except Exception as e:
            return False, f"Unable to read file: {e}"

    def list_directory(self, folder_name: str = "") -> Tuple[bool, str]:
        """List files in directory."""
        try:
            target = self._resolve_safe_path(folder_name) if folder_name else self.desktop_dir
            if not target.exists() or not target.is_dir():
                return False, f"Directory '{target}' not found."

            items = [f.name for f in target.iterdir()][:15]
            if not items:
                return True, f"Directory '{target.name}' is currently empty."
            return True, f"Items in {target.name}: {', '.join(items)}"
        except Exception as e:
            return False, f"Error listing directory: {e}"

    def rename_file(self, old_name: str, new_name: str) -> Tuple[bool, str]:
        """Safely rename a file."""
        try:
            old_p = self._resolve_safe_path(old_name)
            new_p = old_p.parent / new_name
            if not old_p.exists():
                return False, f"Target file '{old_name}' not found."
            old_p.rename(new_p)
            return True, f"Renamed '{old_name}' to '{new_name}'."
        except Exception as e:
            return False, f"Rename failed: {e}"

# Global instance
file_manager = FileManager()

